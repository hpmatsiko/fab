<?php

return [
    'Books' => 'Livres',
    'Search Book' => 'Rechercher un livre',
    'Language' => 'Langue',
    'English' => 'Anglais',
    'French' => 'Français',
    'Kinyarwanda' => 'Kinyarwanda',
    'Register' => 'S inscrire',
    'Login' => 'Se connecter',
];


?>