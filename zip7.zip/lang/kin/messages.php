<?php

return [
    'Books' => 'Ibitabo',
    'Search Book' => 'Shaka Igitabo',
    'Language' => 'Ururimi',
    'English' => 'Icyongereza',
    'French' => 'Igifaransa',
    'Kinyarwanda' => 'IKinyarwanda',
    'Register' => 'Iyandikishe',
    'Login' => 'Injira',
];


?>