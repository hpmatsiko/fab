<?php

return[
	'Books' => 'Books',
	'Language' => 'Language',
	'Register' => 'Register',
	'Login' => 'Login',
	'English'  => 'English',
	'French'  => 'French',
	'Kinyarwanda'  => 'Kinyarwanda',

];

?>