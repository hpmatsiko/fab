<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\AnswerController;
use App\Http\Controllers\LocateController;
use Illuminate\Support\Facades\Route;


Route::get('/', [HomeController::class, 'index'])->name('/');
Route::get("search",[BookController::class,'search'])->name('search');
Route::get("searchi",[DashboardController::class,'searchi'])->name('searchi');
Route::get('/categories/{category}',[HomeController::class, 'show'])->name('categories.show');
Route::get('/viewbook/{book}',[HomeController::class, 'viewbook'])->name('viewbook');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

Route::middleware('auth','admin','verified')->group(function () {
    Route::get('/admin/dashboard', [DashboardController::class, 'index'])->name('admin');
    Route::get('/admin/addBookCat', [DashboardController::class, 'addBookCat'])->name('addBookCat');
    Route::get('/admin/addSubCat/{category}', [DashboardController::class, 'addSubCat'])->name('addSubCat');
    Route::get('/admin/addBook/{subcategory}', [DashboardController::class, 'addBook'])->name('addBook');
    Route::post('/admin/save-book', [BookController::class, 'saveBook'])->name('save.book');
    Route::post('/admin/save-cat', [BookController::class, 'saveCat'])->name('save.category');
    Route::post('/admin/saveSubCat', [BookController::class, 'saveSubCat'])->name('saveSubCat');
    Route::get('/admin/addChap/{book}', [DashboardController::class, 'addChap'])->name('addChap');
    Route::get('/admin/addNote/{chapter}', [DashboardController::class, 'addNote'])->name('addNote');
    Route::get('/admin/addEx/{chapter}', [DashboardController::class, 'addEx'])->name('addEx');
    Route::get('/admin/bookList', [DashboardController::class, 'bookList'])->name('bookList');
    Route::post('/admin/saveChap', [BookController::class, 'saveChap'])->name('saveChap');
    Route::post('/admin/saveNote', [BookController::class, 'saveNote'])->name('saveNote');
    Route::post('/admin/saveEx', [BookController::class, 'saveEx'])->name('saveEx');
    Route::get('/admin/ChooseCat', [DashboardController::class, 'ChooseCat'])->name('ChooseCat');
    Route::get('/admin/ChooseCatBook', [DashboardController::class, 'ChooseCatBook'])->name('ChooseCatBook');
    Route::get('/admin/ChooseSubCat', [DashboardController::class, 'ChooseSubCat'])->name('ChooseSubCat');
    Route::get('/admin/ChooseBook', [DashboardController::class, 'ChooseBook'])->name('ChooseBook');
    Route::get('/admin/ChooseBookL', [DashboardController::class, 'ChooseBookL'])->name('ChooseBookL');
    Route::get('/admin/ChooseBookLN', [DashboardController::class, 'ChooseBookLN'])->name('ChooseBookLN');

    Route::get('/admin/ChooseBookLE', [DashboardController::class, 'ChooseBookLE'])->name('ChooseBookLE');

    Route::get('/admin/ChooseBookLQ', [DashboardController::class, 'ChooseBookLQ'])->name('ChooseBookLQ');

    Route::get('/admin/ChooseBookQ', [DashboardController::class, 'ChooseBookQ'])->name('ChooseBookQ');
    Route::get('/admin/ChooseBookChap', [DashboardController::class, 'ChooseBookChap'])->name('ChooseBookChap');

    Route::get('/admin/ChooseChap/{book}', [DashboardController::class, 'ChooseChap'])->name('ChooseChap');

    Route::get('/admin/ChooseBookEx', [DashboardController::class, 'ChooseBookEx'])->name('ChooseBookEx');

    Route::get('/admin/ChooseChapEx/{book}', [DashboardController::class, 'ChooseChapEx'])->name('ChooseChapEx');
    Route::get('/admin/ChooseEx', [DashboardController::class, 'ChooseEx'])->name('ChooseEx');

    Route::get('/admin/SubCatL', [DashboardController::class, 'SubCatL'])->name('SubCatL');
    Route::get('/admin/CatL', [DashboardController::class, 'CatL'])->name('CatL');
    Route::get('/admin/BookL', [DashboardController::class, 'BookL'])->name('BookL');
    Route::get('/admin/ExLQ/{chapter}', [DashboardController::class, 'ExLQ'])->name('ExLQ');
    Route::get('/admin/ExQ/{chapter}', [DashboardController::class, 'ExQ'])->name('ExQ');
    Route::get('/admin/ExL/{chapter}', [DashboardController::class, 'ExL'])->name('ExL');
    Route::get('/admin/ChapL/{book}', [DashboardController::class, 'ChapL'])->name('ChapL');
    Route::get('/admin/ChapLN/{book}', [DashboardController::class, 'ChapLN'])->name('ChapLN');
    Route::get('/admin/ChapLE/{book}', [DashboardController::class, 'ChapLE'])->name('ChapLE');
    Route::get('/admin/ChapLQ/{book}', [DashboardController::class, 'ChapLQ'])->name('ChapLQ');
    Route::get('/admin/ChapQ/{book}', [DashboardController::class, 'ChapQ'])->name('ChapQ');
    Route::get('/admin/ChapNote/{chapter}', [DashboardController::class, 'ChapNote'])->name('ChapNote');

    Route::get('/exam/create/{exercise}', [ExamController::class, 'createQuestion'])->name('exam.createQuestion');


    Route::post('/exam/create', [ExamController::class, 'storeQuestion'])->name('exam.storeQuestion');


    Route::get('/answers/{answer}/edit', [AnswerController::class, 'edit'])->name('answers.edit');

    Route::put('/answers/{answer}', [AnswerController::class, 'update'])->name('answers.update');
    Route::delete('/answers/{answer}', [AnswerController::class, 'destroy'])->name('answers.destroy');
    Route::post('/questions/{question}/answers', [AnswerController::class, 'store'])->name('answers.store');


    Route::get('/questions/{exercise}', [QuestionController::class, 'index'])->name('questions.index');
    Route::put('/questions/{question}', [QuestionController::class, 'update'])->name('questions.update');
    Route::get('/questions/{question}/edit', [QuestionController::class, 'edit'])->name('questions.edit');
    Route::delete('/questions/{question}', [QuestionController::class, 'destroy'])->name('questions.destroy');



    Route::get('/books/UpdateCat/{cat}', [DashboardController::class, 'UpdateCat'])->name('UpdateCat');
    Route::put('/books/UpdateCat/{cat}', [BookController::class, 'UpdateCat'])->name('UpdateCat');
    Route::put('/books/UpdateSubCat/{subcat}', [BookController::class, 'UpdateSubCat'])->name('UpdateSubCat');
    Route::get('/books/UpdateSubCat/{subcat}', [DashboardController::class, 'UpdateSubCat'])->name('UpdateSubCat');

    Route::put('/books/update/{book}', [BookController::class, 'updateBook'])->name('books.update');

    Route::get('/books/UpdateBook/{book}', [DashboardController::class, 'UpdateBook'])->name('UpdateBook');

    Route::get('/books/UpdateChap/{chapter}', [DashboardController::class, 'UpdateChap'])->name('UpdateChap');

    Route::put('/books/UpdateChap/{chapter}', [BookController::class, 'UpdateChap'])->name('UpdateChap');

    Route::put('/books/UpdateNote/{note}', [BookController::class, 'UpdateNote'])->name('UpdateNote');
    Route::get('/books/UpdateNote/{note}', [DashboardController::class, 'UpdateNote'])->name('UpdateNote');

    Route::get('/books/UpdateEx/{ex}', [DashboardController::class, 'UpdateEx'])->name('UpdateEx');
    Route::put('/books/UpdateEx/{ex}', [BookController::class, 'UpdateEx'])->name('UpdateEx');
    Route::get('/admin/content', [DashboardController::class, 'saveContent'])->name('saveContent');

    Route::put('/admin/content', [ContentController::class, 'UpdateContent'])->name('UpdateContent');
});





Route::middleware('auth','user','verified')->group(function () {
    Route::get('/user/dashboard', [DashboardController::class, 'userd'])->name('user');
});

Route::get('/exam', [ExamController::class, 'show'])->name('exam.show');
Route::post('/exam', [ExamController::class, 'submit'])->name('exam.submit');







Route::get('/exam/results', [ExamController::class, 'showResults'])->name('exam.results');

Route::get('locale/{lang}', [LocateController::class, 'setLocale']);





