  <?php if(Route::has('login')): ?>


  
  <?php $__env->startSection('title', 'Dashboard'); ?>

  <?php $__env->startSection('content'); ?>

  <!-- Content Start -->

  <!-- Navbar Start -->
  <?php echo $__env->make('/admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Navbar End -->

  <style type="text/css" media="screen">
    #dash{
        color: darkblue;
    } 
    #dsh{
        background: #000000;
    } 
</style>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-line fa-3x" style="color:darkblue;"></i>
                <div class="ms-3">
                    <p class="mb-2">Today Sale</p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-bar fa-3x " style="color:darkblue;"></i>
                <div class="ms-3">
                    <p class="mb-2">Total Sale</p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-area fa-3x " style="color:darkblue;"></i>
                <div class="ms-3">
                    <p class="mb-2">Today Revenue</p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-chart-pie fa-3x " style="color:darkblue;"></i>
                <div class="ms-3">
                    <p class="mb-2">Total Revenue</p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Sale & Revenue End -->

<?php echo $__env->make('/admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<!-- Content End -->

<?php $__env->stopSection(); ?>
<?php endif; ?> 



<?php echo $__env->make('/admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\new\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>