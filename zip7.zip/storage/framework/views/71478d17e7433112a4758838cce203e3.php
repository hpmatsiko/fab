<small><div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-6 col-md-6">
                <h6 class="text-ghostwhite mb-3" style="color: white;">Aho unkanda ukabona amakuru yihuse</h6>
                <a style="color: white;" class="btn btn-link"  href="">Ahabanza</a>
                <a style="color: white;" class="btn btn-link" href="">Amafoto</a>
                <a style="color: white;" class="btn btn-link" href="">Ibindi</a>
                <a style="color: white;" class="btn btn-link" href="">Kwiyandikisha</a>
                <a style="color: white;" class="btn btn-link" href="">Kwinjira</a>
            </div>
            <div class="col-lg-3 col-md-3">
                <h6 class="text-ghostwhite mb-3" style="color: white;">Mbese urashaka kwiga ishuri rya Bibiliya mu buryo bukoroheye?<br>

                    Dore aho wabariza inyigisho z’ishuri rya Emmaus:
                </h6>
                <!-- <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>123 Street, New York, USA</p> -->
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>
                    National Coordinator<br>
                    Phone: +250788485518; +250728485518<br>
                    <i class="fa fa-envelope me-3"></i>E-mail: muhiregaudence@yahoo.fr<br>

                </p>
                <p class="mb-2">Deputy Coordinator<br>
                    <i class="fa fa-phone-alt me-3"></i>Phone: +250 788 585 889 <br>
                    <i class="fa fa-envelope me-3"></i>rwaemmaus@yahoo.fr
                </p>
                <div class="d-flex pt-2">
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-md-3">
                <h6 class="text-ghostwhite mb-3" style="color: white;"><i class="fa-solid fa-location-dot" style="margin-right: 1vh;"></i>Aho Dukorera Murwanda
                </h6>
                <p class="mb-2">KIGALI</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>
                  Joseph KAMANZA                  (Coordinateur Adjoint)<br>
                  Tél. Mob 0788585889<br>

                  MUHIRWA Joshua          0788414433<br>
                  NTARUNDENGA André           0788359710

              </p>
              <p class="mb-2">IBURENGERAZUBA<br>
                ZIRIMWABAGABO Em.               0788233144 <br>
                <i class="fa fa-envelope me-3"></i>rwaemmaus@yahoo.fr
            </p>

             <p class="mb-2">IBURASIRAZUBA<br>
                GAKUMBA Cyprien         0783218883<br>
               Nsengiyumva J. Patrick          0784185561<br>
               Nsengiyumva J. Patrick          0784185561
            </p>

             <p class="mb-2">AMAJYEPFO<br>
                HATEGEKIMANA Jean de Dieu   0787699858<br>
               MUSONI Wilberforce          0788485685<br>
               HITIYISE J. Pascale         0788672791
            </p>

        </div>

</div>
</div>
<div class="container">
    <div class="copyright">
        <div class="row">
            <div class="col-md-6 text-center text-md-start mb-6 mb-md-0">
                &copy; <a class="border-bottom" href="#">emausrwanda.com</a>, All Right Reserved.

                <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                Designed By <a class="border-bottom" href="https://htmlcodex.com">HP Matsiko</a>
            </div>

        </div>
    </div>
</div>
</div>
</small><?php /**PATH C:\Users\HP Matsiko\new\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>