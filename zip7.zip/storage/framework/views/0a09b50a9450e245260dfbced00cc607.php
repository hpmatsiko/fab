
<?php $__env->startSection('title', 'Add Question'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    #que {
        color: darkblue;
    } 
    #ques {
        background: #000000;
    } 
</style>
<div style="margin: 4vh 4vh 0vh 4vh;" class="col-sm-12 col-xl-10">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 style="color: darkgrey;" class="mb-4">Edit Question</h6>

        <form action="<?php echo e(route('questions.update', $question->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <label>Question:</label>
            <textarea name="question" id="question" class="form-control"><?php echo e($question->question); ?></textarea>

            <label for="type">Type:</label>
            <select name="type" id="type" class="form-control">
                <option value="single" <?php echo e($question->type == 'single' ? 'selected' : ''); ?>>Single</option>
                <option value="multiple" <?php echo e($question->type == 'multiple' ? 'selected' : ''); ?>>Multiple</option>
            </select>

            <button style="background: #198754;border: none;color: darkgrey;border-radius: .7vh;margin-top:1vh;" type="submit" class="btn btn-primary">Update Question</button>
        </form>

        <hr>

        <h6 style="color: darkgrey;" class="mb-4">Answers</h6>
        <ul>
            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($answer->answer); ?> (<?php echo e($answer->is_correct ? 'Correct' : 'Incorrect'); ?>)
                <a style="background: #198754;border: none;color: darkgrey;border-radius: .7vh;" href="<?php echo e(route('answers.edit', $answer->id)); ?>" class="btn btn-primary">Edit</a>
                <form action="<?php echo e(route('answers.destroy', $answer->id)); ?>" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-primary" style="border: none;color: darkgrey;margin-top:1vh;" type="submit">Remove</button>
                </form>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <hr>

       <h6 style="color: darkgrey;" class="mb-4">Add New Answer</h6>
        <form action="<?php echo e(route('answers.store', $question->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label for="answer">Answer:</label>
            <input type="text" name="answer" id="answer" required class="form-control">

            <label for="is_correct">Is Correct:</label>
            <input type="hidden" name="is_correct" value="0">
            <input type="checkbox" name="is_correct" id="is_correct" value="1">

            <button style="background: #198754;border: none;color: darkgrey;border-radius: .7vh;margin-top:1vh;" type="submit" class="btn btn-primary">Add Answer</button>
        </form>
    </div>
</div>

<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\new\resources\views/questions/edit.blade.php ENDPATH**/ ?>