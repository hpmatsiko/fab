
<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
        #chap{
        color: darkblue;
    } 
    #chapter{
        background: #000000;
    } 
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: darkgrey;" class="mb-4">Chapters List</h6>
                <div class="table-responsive">
                    <?php if($chapters->isEmpty()): ?>
                    <div class="container-fluid pt-4 px-4">
                        <div class="row g-4">


                            <div class="col-sm-12 col-xl-6">
                                <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                                    <p>No any chapter found </p>
                                </div>
                            </div>




                        </div>
                    </div>
                    <?php endif; ?>


                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>

                                <th>Chapter Name</th>
                                <th scope="col">Action</th>
                                

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            

                            <tr>
                                <th scope="row"><?php echo e($index + 1); ?>)</th>
                                <th scope="row"><?php echo e($chapter->chapter); ?></th>
                               
                                <td> <a href="<?php echo e(route('UpdateChap',$chapter->id)); ?>" class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;">Edit</a><a href="" class="btn btn-danger btn-sm" style="color: darkgrey;">Remove</a></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>


                </div>
            </div>
        </div>

    </div>
</div>
</div>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\new\resources\views/admin/ChapL.blade.php ENDPATH**/ ?>