<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NoteModel extends Model
{
    use HasFactory;
    protected $fillable = ['note','chapter_id'];
    protected $table = 'notes';

    public function chapters()
    {
        return $this->belongsTo(ChapterModel::class, 'chapter_id');
    }
}
