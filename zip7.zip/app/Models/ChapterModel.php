<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChapterModel extends Model
{
    use HasFactory;
    protected $fillable = ['chapter','book_id'];
    protected $table = 'chapters';

    public function books()
    {
        return $this->belongsTo(BookModel::class, 'book_id');
    }

     public function notes()
    {
        return $this->hasMany(NoteModel::class, 'chapter_id');
    }

     public function ex()
    {
        return $this->hasMany(ExerciseModel::class, 'chapter_id');
    }
}
