<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubCategoryModel extends Model
{
    use HasFactory;
    protected $fillable = ['sub_category','category_id'];
    protected $table = 'sub_category_models';

    public function bookCategory()
    {
        return $this->belongsTo(BookCategoryModel::class, 'category_id');
    }

     public function books()
    {
        return $this->hasMany(BookModel::class, 'sub_category_id');
    }
}
