<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookModel extends Model
{
    protected $fillable = [
        'bname', 'author', 'publisher','published_date', 'isbn', 'price', 'description', 'image', 'sub_category_id',
    ];
    protected $table = 'books';
    // Define the relationship with sub_category
    public function subCategory()
    {
        return $this->belongsTo(SubCategoryModel::class, 'sub_category_id');
    }

     public function chapters()
    {
        return $this->hasMany(ChapterModel::class, 'book_id');
    }
}
