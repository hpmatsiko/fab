<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExerciseModel extends Model
{
    use HasFactory;

     protected $fillable = ['ex','chapter_id'];
    protected $table = 'exercises';

    public function chapters()
    {
        return $this->belongsTo(ChapterModel::class, 'chapter_id');
    }

     public function questions()
    {
        return $this->hasMany(Question::class);
    }
}
