<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookCategoryModel extends Model
{
    use HasFactory;
    protected $fillable = ['book_category'];
    protected $table = 'book_category_models';

    public function subCategories()
    {
        return $this->hasMany(SubCategoryModel::class, 'category_id');
    }
}
