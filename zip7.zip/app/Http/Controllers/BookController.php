<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\BookCategoryModel;
use App\Models\SubCategoryModel;
use App\Models\BookModel;
use App\Models\ChapterModel;
use App\Models\NoteModel;
use App\Models\ExerciseModel;

class BookController extends Controller
{
    
 public function addBookCat()
 {
    return view('admin/addBookCat');
}

public function saveCat(Request $request)
{
  $validatedData = $request->validate([
        'title' => 'required|string|max:255', // Example validation rule for the title field
    ]);
  
  $data= new BookCategoryModel();
  $data->book_category=$request->title;
  $data->save();
  return redirect()->back()->with('suc','Kategori Nshya Yinjijwe');
}

public function saveSubCat(Request $request)
{
    // Validation rules
  $rules = [
    'sub_category' => 'required|string|max:255',
        'category' => 'required|exists:book_category_models,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'sub_category.required' => 'The sub category field is required.',
       'category.required' => 'The category field is required.',
       'category.exists' => 'The selected category is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $data = new SubCategoryModel();
   $data->sub_category = $request->sub_category;
   $data->category_id = $request->category;
   $data->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Icyiciro Gishya Cyinjijwe');
}

public function saveBook(Request $request)
{
    // Validate the incoming request data
    $rules = [

        'bname' => 'required|string|max:255',
        'price' => 'required|numeric',
        'description' => 'required|string',
        'author' => 'nullable|string|max:255',
        'publisher' => 'nullable|string|max:255',
        'isbn' => 'nullable|string|max:255',
        'published_date' => 'nullable|date',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Max 2MB image
        'sub_category_id' => 'required|exists:sub_category_models,id' // Valid subcategory ID
    ];

    $messages = [
        'bname.required' => 'The book name is required.',
        'bname.string' => 'The book name must be a string.',
        'bname.max' => 'The book name may not be greater than 255 characters.',

        'price.required' => 'The price is required.',
        'price.numeric' => 'The price must be a numeric value.',

        'description.required' => 'The description is required.',
        'description.string' => 'The description must be a string.',

        'author.string' => 'The author must be a string.',
        'author.max' => 'The author may not be greater than 255 characters.',

        'publisher.string' => 'The publisher must be a string.',
        'publisher.max' => 'The publisher may not be greater than 255 characters.',

        'isbn.string' => 'The ISBN must be a string.',
        'isbn.max' => 'The ISBN may not be greater than 255 characters.',

        'published_date.date' => 'The published date must be a valid date format.',

        'image.image' => 'The file must be an image.',
        'image.mimes' => 'The image must be a file of type: jpeg, png, jpg, gif.',
        'image.max' => 'The image may not be greater than 2MB.',

        'sub_category_id.required' => 'The subcategory ID is required.',
        'sub_category_id.exists' => 'The selected subcategory ID is invalid.',
    ];
  // Validate the request data
    $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
    if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }
   $book = new BookModel();
   $book->bname = $request->bname;
   $book->price = $request->price;
   $book->description = $request->description;
   $book->author = $request->author;
   $book->publisher = $request->publisher;
   $book->isbn = $request->isbn;
   $book->published_date = $request->published_date;
   $book->sub_category_id = $request->sub_category_id;

    // Handle image upload if exists
   if ($request->hasFile('image')) {
    $image = $request->file('image');
    $imageName = time() . '_' . $image->getClientOriginalName();
    $image->move(public_path('bookImages'), $imageName);
    $book->image = $imageName;
}

$book->save();
return redirect()->back()->with('suc', 'Igitabo Gishya Cyinjijwe');


}

public function saveChap(Request $request)
{
    // Validation rules
  $rules = [
    'chapter' => 'required|string|max:255',
        'book_id' => 'required|exists:books,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'chapter.required' => 'The Chapter field is required.',
       'book_id.required' => 'The Book Selection is required.',
       'book_id.exists' => 'The selected Book is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $data = new ChapterModel();
   $data->chapter = $request->chapter;
   $data->book_id = $request->book_id;
   $data->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Shapitire Yinjijwe');
}


public function saveNote(Request $request)
{
    // Validation rules
  $rules = [
    'note' => 'required|string|max:255',
        'chapter_id' => 'required|exists:chapters,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'note.required' => 'The Chapter field is required.',
       'chapter_id.required' => 'The Chapter Selection is required.',
       'chapter_id.exists' => 'The selected Chapter is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $data = new NoteModel();
   $data->note = $request->note;
   $data->chapter_id = $request->chapter_id;
   $data->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Notes Zinjijwe');
}



public function saveEx(Request $request)
{
    // Validation rules
  $rules = [
    'exercise' => 'required|string|max:255',
        'chapter_id' => 'required|exists:chapters,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'exercise.required' => 'The field is required.',
       'chapter_id.required' => 'The Chapter Selection is required.',
       'chapter_id.exists' => 'The selected Chapter is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $data = new ExerciseModel();
   $data->ex = $request->exercise;
   $data->chapter_id = $request->chapter_id;
   $data->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Exercise name entered');
}

public function search(Request $request)
{
    if ($request->ajax()) {
        $searchTerm = $request->search;

        if (!empty($searchTerm)) {
            $data = BookModel::where('bname', 'like', '%' . $searchTerm . '%')
                ->orWhere('description', 'like', '%' . $searchTerm . '%')
                ->get();

            $output = count($data) > 0 ? '<h3>Books</h3><ol>' : '<h3>No results</h3>';

            if (count($data) > 0) {
                foreach ($data as $row) {
                    $output .= '<a href="' . route("login") . '" class="dropdown-item"><li>' . $row->bname . '</li></a>';
                }
                $output .= '</ol>';
            }

            return response()->json(['html' => $output]);
        }

        return response()->json(['html' => '']);
    }

    return '';
}


public function UpdateCat(Request $request, $cat)
{
  $validatedData = $request->validate([
        'title' => 'required|string|max:255', // Example validation rule for the title field
    ]);
  
  $category= BookCategoryModel::find($cat);
  $category->book_category=$request->title;
  $category->save();
  return redirect()->back()->with('suc','Kategori Yavuguruwe Neza');
}

public function UpdateSubCat(Request $request, $subcat)
{
    // Validation rules
  $rules = [
    'sub_category' => 'required|string|max:255',
        'category' => 'required|exists:book_category_models,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'sub_category.required' => 'The sub category field is required.',
       'category.required' => 'The category field is required.',
       'category.exists' => 'The selected category is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $sub_category = SubCategoryModel::find($subcat);
   $sub_category->sub_category = $request->sub_category;
   $sub_category->category_id = $request->category;
   $sub_category->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Sub-category updated successfully');
}


public function updateBook(Request $request, $book)
{
    // Validate the incoming request data
    $rules = [
        'bname' => 'required|string|max:255',
        'price' => 'required|numeric',
        'description' => 'required|string',
        'author' => 'nullable|string|max:255',
        'publisher' => 'nullable|string|max:255',
        'isbn' => 'nullable|string|max:255',
        'published_date' => 'nullable|date',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Max 2MB image
        'sub_category_id' => 'required|exists:sub_category_models,id' // Valid subcategory ID
    ];

    $messages = [
        'bname.required' => 'The book name is required.',
        'bname.string' => 'The book name must be a string.',
        'bname.max' => 'The book name may not be greater than 255 characters.',

        'price.required' => 'The price is required.',
        'price.numeric' => 'The price must be a numeric value.',

        'description.required' => 'The description is required.',
        'description.string' => 'The description must be a string.',

        'author.string' => 'The author must be a string.',
        'author.max' => 'The author may not be greater than 255 characters.',

        'publisher.string' => 'The publisher must be a string.',
        'publisher.max' => 'The publisher may not be greater than 255 characters.',

        'isbn.string' => 'The ISBN must be a string.',
        'isbn.max' => 'The ISBN may not be greater than 255 characters.',

        'published_date.date' => 'The published date must be a valid date format.',

        'image.image' => 'The file must be an image.',
        'image.mimes' => 'The image must be a file of type: jpeg, png, jpg, gif.',
        'image.max' => 'The image may not be greater than 2MB.',

        'sub_category_id.required' => 'The subcategory ID is required.',
        'sub_category_id.exists' => 'The selected subcategory ID is invalid.',
    ];

    // Validate the request data
    $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
    if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
        return redirect()->back()->withErrors($validator)->withInput();
    }

    // Find the book by ID
    $book = BookModel::find($book);
    if (!$book) {
        return redirect()->back()->with('error', 'Book not found.');
    }

    // Update the book details
    $book->bname = $request->bname;
    $book->price = $request->price;
    $book->description = $request->description;
    $book->author = $request->author;
    $book->publisher = $request->publisher;
    $book->isbn = $request->isbn;
    $book->published_date = $request->published_date;
    $book->sub_category_id = $request->sub_category_id;

    // Handle image upload if exists
    if ($request->hasFile('image')) {
        // Delete the old image if exists
        if ($book->image && file_exists(public_path('bookImages/' . $book->image))) {
            unlink(public_path('bookImages/' . $book->image));
        }

        $image = $request->file('image');
        $imageName = time() . '_' . $image->getClientOriginalName();
        $image->move(public_path('bookImages'), $imageName);
        $book->image = $imageName;
    }

    $book->save();
    return redirect()->back()->with('suc', 'Igitabo Cyavuguruwe Neza');
}



public function UpdateChap(Request $request, $chapter)
{
    // Validation rules
  $rules = [
    'chapter' => 'required|string|max:255',
        'book_id' => 'required|exists:books,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'chapter.required' => 'The Chapter field is required.',
       'book_id.required' => 'The Book Selection is required.',
       'book_id.exists' => 'The selected Book is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $chap =ChapterModel::find($chapter);
   $chap->chapter = $request->chapter;
   $chap->book_id = $request->book_id;
   $chap->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Chapter updated successfully');
}

public function UpdateNote(Request $request, $note)
{
    // Validation rules
  $rules = [
    'note' => 'required|string|max:255',
        'chapter_id' => 'required|exists:chapters,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'note.required' => 'The Chapter field is required.',
       'chapter_id.required' => 'The Chapter Selection is required.',
       'chapter_id.exists' => 'The selected Chapter is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $note = NoteModel::find($note);
   $note->note = $request->note;
   $note->chapter_id = $request->chapter_id;
   $note->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Notes updated successfully');
}


public function UpdateEx(Request $request, $ex)
{
    // Validation rules
  $rules = [
    'exercise' => 'required|string|max:255',
        'chapter_id' => 'required|exists:chapters,id', // Assuming 'categories' is the table name for categories
    ];

    // Custom validation messages
    $messages = [
       'exercise.required' => 'The field is required.',
       'chapter_id.required' => 'The Chapter Selection is required.',
       'chapter_id.exists' => 'The selected Chapter is invalid.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $exercise = ExerciseModel::find($ex);
   $exercise->ex = $request->exercise;
   $exercise->chapter_id = $request->chapter_id;
   $exercise->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Exercise name updated successfully');
}


}
