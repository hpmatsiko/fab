<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Models\BookCategoryModel;
use App\Models\SubCategoryModel;
use App\Models\BookModel;
use App\Models\ChapterModel;
use App\Models\NoteModel;

class EmailVerificationPromptController extends Controller
{
    /**
     * Display the email verification prompt.
     */
    public function __invoke(Request $request): RedirectResponse|View
    {
        $bookCategories = BookCategoryModel::with('subCategories.books.chapters')->get();
        return $request->user()->hasVerifiedEmail()
                    ? redirect()->intended(route('login', absolute: false))
                    : view('auth.verify-email',compact('bookCategories'));
    }
}
