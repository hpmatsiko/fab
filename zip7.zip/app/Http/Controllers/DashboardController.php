<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BookCategoryModel;
use App\Models\SubCategoryModel;
use App\Models\BookModel;
use App\Models\ChapterModel;
use App\Models\ExerciseModel;
use App\Models\NoteModel;

class DashboardController extends Controller
{
   public function index()
   {
        // Retrieve all book categories along with their sub-categories
    $bookCategories = BookCategoryModel::with('subCategories.books.chapters')->get();

        // Pass the data to a view
    return view('admin.dashboard', compact('bookCategories'));
}

public function userd()
{

    $bookCategories = BookCategoryModel::with('subCategories.books.chapters')->get();
        // Pass the data to a view
    return view('dashboard',compact('bookCategories'));
}


public function ChooseCat()
{

    $bookCategories = BookCategoryModel::all();
        // Pass the data to a view
    return view('admin.ChooseCat',compact('bookCategories'));
}

public function CatL()
{

    $bookCategories = BookCategoryModel::all();
        // Pass the data to a view
    return view('admin.CategoryL',compact('bookCategories'));
}


public function SubCatL()
{

    $bookCategories = BookCategoryModel::with('subCategories')->get();
        // Pass the data to a view
    return view('admin.SubCatL',compact('bookCategories'));
}


public function ChooseEx()
{

    $exercises = ExerciseModel::all();
        // Pass the data to a view
    return view('admin.ChooseEx',compact('exercises'));
}


public function ChooseBook()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBook',compact('books'));
}

public function ChooseBookL()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookL',compact('books'));
}

public function ChooseBookLN()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookLN',compact('books'));
}

public function ChooseBookLE()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookLE',compact('books'));
}

public function ChooseBookLQ()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookLQ',compact('books'));
}

public function ChooseBookQ()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookQ',compact('books'));
}

public function ChapL(ChapterModel $book)
{

    $chapters = ChapterModel::all();
        // Pass the data to a view
    return view('admin.ChapL',compact('chapters','book'));
}

public function ChapLQ(ChapterModel $book)
{

    $chapters = ChapterModel::all();
        // Pass the data to a view
    return view('admin.ChapLQ',compact('chapters','book'));
}

public function ChapQ(ChapterModel $book)
{

    $chapters = ChapterModel::all();
        // Pass the data to a view
    return view('admin.ChapQ',compact('chapters','book'));
}

public function ExLQ(ChapterModel $chapter)
{

    $exercises = ExerciseModel::all();
        // Pass the data to a view
    return view('admin.ExLQ',compact('exercises','chapter'));
}

public function ExQ(ChapterModel $chapter)
{

    $exercises = ExerciseModel::all();
        // Pass the data to a view
    return view('admin.ExQ',compact('exercises','chapter'));
}


public function ExL(ChapterModel $chapter)
{

    $exercises = ExerciseModel::where('chapter_id',$chapter->id)->get();
        // Pass the data to a view
    return view('admin.ExL',compact('exercises','chapter'));
}

public function ChapLN(ChapterModel $book)
{

    $chapters = ChapterModel::all();
        // Pass the data to a view
    return view('admin.ChapLN',compact('chapters','book'));
}

public function ChapLE(ChapterModel $book)
{

    $chapters = ChapterModel::all();
        // Pass the data to a view
    return view('admin.ChapLE',compact('chapters','book'));
}


public function ChooseBookChap()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookChap',compact('books'));
}

public function ChooseBookEx()
{

    $books = BookModel::all();
        // Pass the data to a view
    return view('admin.ChooseBookEx',compact('books'));
}

public function ChapNote(ChapterModel $chapter)
{

    $notes = NoteModel::where('chapter_id',$chapter->id)->get();
        // Pass the data to a view
    return view('admin.ChapNote',compact('notes','chapter'));
}

public function ChooseSubCat()
{

   $SubCategories = SubCategoryModel::all();
        // Pass the data to a view
   return view('admin.ChooseSubCat',compact('SubCategories'));
}


public function addBook(SubCategoryModel $subcategory)
{

 return view('admin/addBook',compact('subcategory')); 
}

public function ChooseChap(BookModel $book)
{
 $chapters= ChapterModel::where('book_id',$book->id)->get();
 return view('admin/ChooseChap',compact('chapters')); 
}

public function ChooseChapEx(BookModel $book)
{
 $chapters= ChapterModel::where('book_id',$book->id)->get();
 return view('admin/ChooseChapEx',compact('chapters')); 
}


public function addBookCat()
{
  return view('admin/addBookCat'); 
}



public function addSubCat(BookCategoryModel $category)
{

  return view('admin/addSubCategory',compact('category')); 
}


public function addChap(BookModel $book)
{

    return view('admin/addChap',compact('book')); 
}

public function addNote(ChapterModel $chapter)
{

    return view('admin/addNote',compact('chapter')); 
}

public function addWell()
{

    return view('admin/addWel'); 
}

public function addEx(ChapterModel $chapter)
{

   return view('admin/addEx',compact('chapter')); 
}

public function bookL()
{
    $bookCat=BookCategoryModel::with('subCategories.books')->get();
    return view('admin/bookL',compact('bookCat')); 
}

public function searchi()
{
    return view('search'); 
}


public function UpdateCat(BookCategoryModel $cat)
{
  return view('admin/UpdateCat',compact('cat')); 
}


public function UpdateSubCat(SubCategoryModel $subcat)
{
  $bookcat=BookCategoryModel::where('id', $subcat->category_id)->get();
  $allbookcat=BookCategoryModel::all();
  return view('admin/UpdateSubCat',compact('subcat','bookcat','allbookcat')); 
}

public function UpdateBook(BookModel $book)
{
    $SubCategory=SubCategoryModel::where('id', $book->sub_category_id)->get();
    
    $allSubcat=SubCategoryModel::all();

    return view('admin.UpdateBook',compact('book','SubCategory','allSubcat')); 
}


public function UpdateChap(ChapterModel $chapter)
{
    $book=BookModel::where('id',$chapter->book_id)->get();
    $allbook=BookModel::all();
    return view('admin/UpdateChap',compact('chapter','book','allbook')); 
}


public function UpdateNote(NoteModel $note)
{
    $chapter= ChapterModel::where('id',$note->chapter_id)->get();
    $allchapter= ChapterModel::all();

    return view('admin/UpdateNote',compact('note','chapter','allchapter')); 
}

public function UpdateEx(ExerciseModel $ex)
{

    $chapter= ChapterModel::where('id',$ex->chapter_id)->get();
    $allchapter= ChapterModel::all();
    return view('admin/UpdateEx',compact('ex','chapter','allchapter')); 
}


public function UpdateContent()
{

   
    return view('admin/UpdateContent'); 
}


}
