<?php

namespace App\Http\Controllers;


use App\Models\Question;
use App\Models\Answer;
use App\Models\ExamResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\ExerciseModel;

class ExamController extends Controller
{
    public function show()
    {
        $questions = Question::with('answers')->get();
        return view('exam', compact('questions'));
    }

    public function submit(Request $request)
    {
        $correctAnswers = 0;
        $totalQuestions = Question::count();

        foreach ($request->input('answers') as $questionId => $answerIds) {
            $question = Question::find($questionId);

            if ($question->type == 'single') {
                $answer = Answer::find($answerIds);
                $isCorrect = $answer && $answer->is_correct;
                if ($isCorrect) {
                    $correctAnswers++;
                }

            // Save result
                ExamResult::create([
                //'user_id' => Auth::id(),
                    'user_id' => 1,
                    'question_id' => $questionId,
                    'answer_id' => $answer ? $answer->id : null,
                    'is_correct' => $isCorrect,
                ]);

            } elseif ($question->type == 'multiple') {
                $correctAnswerIds = $question->answers()->where('is_correct', true)->pluck('id')->toArray();
                $isCorrect = array_diff($correctAnswerIds, $answerIds) == [] && array_diff($answerIds, $correctAnswerIds) == [];
                if ($isCorrect) {
                    $correctAnswers++;
                }

            // Save result for each selected answer
                foreach ($answerIds as $answerId) {
                    ExamResult::create([
                    //'user_id' => Auth::id(),
                        'user_id' => 1,
                        'question_id' => $questionId,
                        'answer_id' => $answerId,
                        'is_correct' => in_array($answerId, $correctAnswerIds),
                    ]);
                }
            }
        }

        $score = ($correctAnswers / $totalQuestions) * 100;

        return redirect()->route('exam.results')->with('message', "You scored $score%");
    }

    public function createQuestion(ExerciseModel $exercise)
    {
        return view('questions.create_question',compact('exercise'));
    }
    public function storeQuestion(Request $request)
    {
        $request->validate([
            'question' => 'required|string',
            'type' => 'required|in:single,multiple',
            'answers' => 'required|array|min:1',
            'answers.*.answer' => 'required|string',
        'answers.*.is_correct' => 'nullable|boolean', // Making is_correct field optional
        'ex_id' => 'required|exists:exercises,id',
    ]);

        $question = Question::create([
            'question' => $request->input('question'),
            'type' => $request->input('type'),
            'ex_id' => $request->input('ex_id'),
        ]);

        foreach ($request->input('answers') as $answerData) {
        // If is_correct field is not present or is null, set it to false
            $isCorrect = isset($answerData['is_correct']) ? $answerData['is_correct'] : false;

            $question->answers()->create([
                'answer' => $answerData['answer'],
                'is_correct' => $isCorrect,
            ]);
        }


        $exercise = $request->input('exercise');


        return redirect()->back()->with('message', 'Question added successfully!');
    }


    public function showResults()
    {
        //$results = ExamResult::where('user_id', Auth::id())->with('question', 'answer')->get();
        $results = ExamResult::where('user_id', 1)->with('question', 'answer')->get();

        return view('exam.results', compact('results'));
    }

}
