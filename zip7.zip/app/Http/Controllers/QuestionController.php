<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Question;
use App\Models\ExerciseModel;

class QuestionController extends Controller
{
    public function index(ExerciseModel $exercise)
    {
        $questions = Question::where('ex_id',$exercise->id)->get();
        return view('questions.index', compact('questions','exercise'));
    }

    public function edit($questionId)
    {
        $question = Question::findOrFail($questionId);
        $exercises=ExerciseModel::where('id',$questionId)->get();
        $allexercises=ExerciseModel::all();
        return view('questions.edit', compact('question','exercises','allexercises'));
    }

    public function update(Request $request, $questionId)
    {
        $question = Question::findOrFail($questionId);
        $question->update($request->all());
        return redirect()->route('questions.edit', $question->id)->with('message', 'Question updated successfully!');
    }

     public function destroy($questionId)
    {
        $question = Question::findOrFail($questionId);
        $question->answers()->delete(); 
        $question->delete();
        return redirect()->back()->with('message', 'Question deleted successfully!');
    }
}