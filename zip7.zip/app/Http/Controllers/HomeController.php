<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BookCategoryModel;
use App\Models\SubCategoryModel;
use App\Models\BookModel;
use App\Models\ChapterModel;
use App\Models\NoteModel;

class HomeController extends Controller
{

  public function show(BookCategoryModel $category)
  {
    $bookCategories = BookCategoryModel::with('subCategories.books.chapters')->get();

    $subcategories = SubCategoryModel::where('category_id', $category->id)->get();
    $books = BookModel::whereIn('sub_category_id', $subcategories->pluck('id'))->get();

    return view('show', compact('bookCategories','subcategories','category', 'books'));
  }

  public function index()
  {
    $bookCategories = BookCategoryModel::with('subCategories.books.chapters')->get();
    return view('welcome',compact('bookCategories')); 
  }
public function viewbook(BookModel $book)
{
    // Retrieve book categories (assuming you need them in the view)
    $bookCategories = BookCategoryModel::with('subCategories.books.chapters')->get();

    // Retrieve subcategory for the given book
    $subCat = SubCategoryModel::where('id', $book->sub_category_id)->first();

    // Retrieve category for the subcategory
    $category = BookCategoryModel::where('id', $subCat->category_id)->first();

    // Retrieve all chapters for the given book
    $chapters = ChapterModel::where('book_id', $book->id)->get();

    // Retrieve the first chapter for the given book
    $firstChapter = $chapters->first();

    // Retrieve notes for the first chapter, if it exists
    $notes = collect();
    if ($firstChapter) {
        $notes = NoteModel::where('chapter_id', $firstChapter->id)->get();
    }

    return view('user.viewbook', compact('bookCategories', 'book', 'chapters', 'firstChapter', 'notes', 'category', 'subCat'));
}


}
