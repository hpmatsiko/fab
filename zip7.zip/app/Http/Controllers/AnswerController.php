<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\Answer;

class AnswerController extends Controller
{
    public function edit($answerId)
    {
        $answer = Answer::findOrFail($answerId);
        return view('answers.edit', compact('answer'));
    }

   public function update(Request $request, $answerId)
{
    $answer = Answer::findOrFail($answerId);
    
    // Update answer fields
    $answer->answer = $request->input('answer');
    $answer->is_correct = $request->has('is_correct'); // Set is_correct based on checkbox
    
    $answer->save();

    return redirect()->route('answers.edit', $answer->id)->with('message', 'Answer updated successfully!');
}

 public function destroy($answerId)
    {
        $answer = Answer::findOrFail($answerId);
        $answer->delete();
        return redirect()->back()->with('message', 'Answer deleted successfully!');
    }


    public function store(Request $request, $questionId)
    {
        $question = Question::findOrFail($questionId);

        $request->validate([
            'answer' => 'required|string',
            'is_correct' => 'required|boolean',
        ]);

        $answer = new Answer([
            'answer' => $request->input('answer'),
            'is_correct' => $request->input('is_correct'),
        ]);

        $question->answers()->save($answer);

        return redirect()->back()->with('message', 'Answer added successfully!');
    }
}

