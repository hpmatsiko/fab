<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ContentModel;

class ContentController extends Controller
{
    public function saveContent(Request $request)
{
    // Validation rules
  $rules = [
    'content' => 'required|string|max:10000000',
       
    ];

    // Custom validation messages
    $messages = [
       'content.required' => 'The field is required.',
   ];

    // Validate the request data
   $validator = Validator::make($request->all(), $rules, $messages);

    // Check if the validation fails
   if ($validator->fails()) {
        // If validation fails, redirect back with errors and old input
       return redirect()->back()->withErrors($validator)->withInput();
   }

    // If validation passes, save the data
   $data =new ContentModel();
   $data->content = $request->content;
   $data->save();

    // Redirect back with success message
   return redirect()->back()->with('suc', 'Contents updated');
}
}
