@extends('layouts.common')
@section('title','Home Page')
@section('content')
@include('layouts.includes.services')
@endsection