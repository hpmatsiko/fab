<!-- resources/views/exam.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Online Exam</title>
</head>
<body>
    @if (session('message'))
        <p>{{ session('message') }}</p>
    @endif

    <form id="exam-form" action="{{ route('exam.submit') }}" method="POST">
        @csrf
        @foreach ($questions as $question)
            <div>
                <p>{{ $question->question }}</p>
                @if ($question->type == 'single')
                    @foreach ($question->answers as $answer)
                        <label>
                            <input type="radio" name="answers[{{ $question->id }}]" value="{{ $answer->id }}">
                            {{ $answer->answer }}
                        </label><br>
                    @endforeach
                @elseif ($question->type == 'multiple')
                    @foreach ($question->answers as $answer)
                        <label>
                            <input type="checkbox" name="answers[{{ $question->id }}][]" value="{{ $answer->id }}">
                            {{ $answer->answer }}
                        </label><br>
                    @endforeach
                @endif
            </div>
        @endforeach
        <button type="submit">Submit</button>
    </form>
</body>
</html>
