@props(['status'])

@if ($status)
    <div style="color: #06BBCC;">
        {{ $status }}
    </div>
@endif


