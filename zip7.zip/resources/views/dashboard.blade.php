@extends('user.common')
@section('title','Home Page')
@section('content')
@include('user/includes/services')
@endsection