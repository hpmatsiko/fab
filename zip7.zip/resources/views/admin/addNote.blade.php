@extends('admin/layouts.common')
@section('title', 'Add Book Category')
@section('content')
@include('admin/layouts/includes/nav')
<style type="text/css">
    #not{
        color: darkblue;
    } 
    #note{
        background: #000000;
    } 
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div style="" class="col-sm-12 col-xl-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: #198754;" class="mb-4">Entering Note</h6>

                <!-- Display Success Message -->
                @if(session('suc'))
                <div class="alert alert-success">
                    {{ session('suc') }}
                </div>
                @endif

                <form method="post" action="{{ route('saveNote') }}" enctype="multipart/form-data">
                    @csrf


                    <div class="row mb-3">

                        <div class="col-sm-12">
                           <input type="hidden" name="chapter_id" value="{{ $chapter->id }}">
                       </div>
                   </div>

                   <div class="row mb-3">
                    <div class="col-sm-12">
                        <textarea id="note" class="form-control @error('note') is-invalid @enderror" name="note" placeholder="Write Notes">{{ old('note') }}</textarea>
                        @error('note')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                </div>

                <button style="background: #198754;border: none;color: darkgrey;" type="submit" class="btn btn-primary">Kwinjiza</button>
            </form>
        </div>
    </div>
</div>
</div>
<script src="/tinymce/tinymce.min.js"></script>
<script type="text/javascript" >
    tinymce.init({
        selector: 'textarea#note',

        height: 700,
        plugins:[
        'advlist', 'autolink', 'link', 'image', 'lists', 'charmap', 'prewiew', 'anchor', 'pagebreak',
        'searchreplace', 'wordcount', 'visualblocks', 'code', 'fullscreen', 'insertdatetime', 'media', 
        'table', 'emoticons', 'template', 'codesample'
        ],
        toolbar: 'undo redo | styles | bold italic underline | alignleft aligncenter alignright alignjustify |' + 
        'bullist numlist outdent indent | link image | print preview media fullscreen | ' +
        'forecolor backcolor emoticons',
        menu: {
            favs: {title: 'menu', items: 'code visualaid | searchreplace | emoticons'}
        },
        menubar: 'favs file edit view insert format tools table',
        content_style: 'body{font-family:Helvetica,Arial,sans-serif; font-size:16px}'
    });
</script>
@include('admin/layouts/includes/footer') 

@endsection
