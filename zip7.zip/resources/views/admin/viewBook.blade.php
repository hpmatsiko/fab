<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<iframe style="width: 100%;height: 100vh" src="/assets/{{ $data->file }}"></iframe>
</body>
</html>