@extends('admin/layouts.common')
@section('title', 'Add Book chapter')
@section('content')
@include('admin/layouts/includes/nav')
<style type="text/css">
    #ex{
        color: darkblue;
    } 
    #exer{
        background: #000000;
    } 
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div style="" class="col-sm-12 col-xl-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: #198754;" class="mb-4">Enter an Exercise</h6>

                <!-- Display Success Message -->
                @if(session('suc'))
                <div class="alert alert-success">
                    {{ session('suc') }}
                </div>
                @endif

                <form method="post" action="{{ route('saveEx') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="row mb-3">

                        <div class="col-sm-12">
                            <input type="text" class="form-control @error('exercise') is-invalid @enderror" id="exercise" name="exercise" value="{{ old('exercise') }}" placeholder="Enter an Exercise">
                            @error('exercise')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>


                    <div class="row mb-3">

                        <div class="col-sm-12">
                         <input type="hidden" name="chapter_id" value="{{ $chapter->id }}" placeholder="">
                     </div>
                 </div>

                 <button style="background: #198754;border: none;color: darkgrey;" type="submit" class="btn btn-primary">Kwinjiza</button>
             </form>
         </div>
     </div>
 </div>
</div>
@include('admin/layouts/includes/footer') 

@endsection
