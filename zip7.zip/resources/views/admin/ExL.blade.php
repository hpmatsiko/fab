@extends('admin/layouts.common')
@section('title', 'Add Book Category')
@section('content')
@include('admin/layouts/includes/nav')
<style type="text/css">
        #ex{
        color: darkblue;
    } 
    #exer{
        background: #000000;
    } 
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: darkgrey;" class="mb-4">Exercises List</h6>
                <div class="table-responsive">
                    @if($exercises->isEmpty())
                    <div class="container-fluid pt-4 px-4">
                        <div class="row g-4">


                            <div class="col-sm-12 col-xl-6">
                                <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                                    <p>No any exercise found </p>
                                </div>
                            </div>




                        </div>
                    </div>
                    @endif


                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>

                                <th>Exercise Name</th>
                                <th scope="col">Action</th>
                                

                            </tr>
                        </thead>
                        <tbody>
                            @foreach($exercises as $index => $exercise)
                            

                            <tr>
                                <th scope="row">{{ $index + 1 }}</th>
                                <th scope="row">{{ $exercise->ex }}</th>
                               
                                <td> <a href="{{ route('UpdateEx',$exercise->id) }}" class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;">Edit</a><a href="" class="btn btn-danger btn-sm" style="color: darkgrey;">Remove</a></td>

                            </tr>
                            @endforeach
                            
                        </tbody>
                    </table>


                </div>
            </div>
        </div>

    </div>
</div>
</div>
@include('admin/layouts/includes/footer') 

@endsection
