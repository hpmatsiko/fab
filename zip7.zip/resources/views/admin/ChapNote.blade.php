
@extends('admin/layouts.common')
@section('title', 'Add Book Category')
@section('content')
@include('admin/layouts/includes/nav')

@if($notes->isEmpty())

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">


        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

             <p>No any note found </p>
         </div>
     </div>




 </div>
</div>

@else
@foreach ($notes as $note)
<style type="text/css" media="screen">
    #not{
        color: darkblue;
    } 
    #note{
        background: #000000;
    }
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">


        <div class="col-sm-12 col-xl-9">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                {!! $note->note !!}
            </div>
        </div>

        <div class="col-sm-12 col-xl-3">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

               <a href="{{ route('UpdateNote',$note->id) }}" class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;">Edit</a>
               <a href="" class="btn btn-danger btn-sm" style="color: darkgrey;">Remove</a>
           </div>
       </div>






   </div>
</div>
@endforeach
@endif



@include('admin/layouts/includes/footer') 

@endsection
