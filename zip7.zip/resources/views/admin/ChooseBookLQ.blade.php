
@extends('admin/layouts.common')
@section('title', 'Add Book Category')
@section('content')
@include('admin/layouts/includes/nav')
@foreach ($books as $book)
<style type="text/css">
    #que {
        color: darkblue;
    } 
    #ques {
        background: #000000;
    } 
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">

        <a class="col-sm-12 col-xl-6" href="{{ route('ChapLQ', $book->id) }}">
        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">
 
            {{ $book->bname }}
            </div>
        </div>

        </a>


    </div>
</div>
@endforeach



@include('admin/layouts/includes/footer') 

@endsection