@extends('admin/layouts.common')
@section('title', 'Add Book Category')
@section('content')
@include('admin/layouts/includes/nav')
<style type="text/css">
    #chap{
        color: #6C7293;
    } 
    #chapter{
        background: #000000;
    } 
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div style="" class="col-sm-12 col-xl-10">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: #198754;" class="mb-4">Enter Chapter Name</h6>

                <!-- Display Success Message -->
                @if(session('suc'))
                <div class="alert alert-success">
                    {{ session('suc') }}
                </div>
                @endif

                <form method="post" action="{{ route('UpdateChap',$chapter->id) }}" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="row mb-3">

                        <div class="col-sm-12">
                            <input type="text" class="form-control @error('sub_category') is-invalid @enderror" id="chapter" name="chapter" value="{{ $chapter->chapter }}" placeholder="Uzuza Izina Rya Shapitire">
                            @error('chapter')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>


                    <div class="row mb-3">

                        <div class="col-sm-12">

                           <select class="form-control" name="book_id">
                            <option value="{{ $chapter->book_id }}">
                                @foreach($book as $bookk)
                                {{ $bookk->bname }}
                                @endforeach
                            </option>
                            
                            @foreach($allbook as $allb)
                            <option value="{{ $allb->id }}">{{ $allb->bname }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <button style="background: #198754;border: none;color: darkgrey;" type="submit" class="btn btn-primary">Kwinjiza</button>
            </form>
        </div>
    </div>
</div>
</div>
@include('admin/layouts/includes/footer') 

@endsection
