
@extends('admin/layouts.common')
@section('title', 'Add Book Category')
@section('content')
@include('admin/layouts/includes/nav')

@if($chapters->isEmpty())
   
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">

      
        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">
 
             <p>No any chapter found </p>
            </div>
        </div>

        


    </div>
</div>

@else
@foreach ($chapters as $chapter)
<style type="text/css" media="screen">
        #not{
        color: darkblue;
    } 
    #note{
        background: #000000;
    }
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">

        <a class="col-sm-12 col-xl-6" href="{{ route('addNote', $chapter->id) }}">
        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">
 
            {{ $chapter->chapter }}
            </div>
        </div>

        </a>


    </div>
</div>
@endforeach
@endif



@include('admin/layouts/includes/footer') 

@endsection
