@extends('user.common')
@section('title','Home Page')
@section('content')
 <div class="container-xxl py-5">
    <div class="container">
        <div style="display: flex;justify-content: space-around;" class="row g-4">
        	<h1 style="text-transform: uppercase;">{{ $category->book_category }} {{ $subCat->sub_category }}</h1>
        	
<h3>{{ $book->bname }}</h3>



        <div class="col-lg-3 col-sm-0 wow fadeInUp" data-wow-delay="0.7s" style="word-break: break-all;">
    <div class="service-item text-center pt-3">
        <div class="p-4" style="text-align: left;">
            @if ($chapters->isEmpty())
                <p>No chapters in this book.</p>
            @else
                @foreach ($chapters as $chapter)
                    <h5 style="line-height: 5vh;">{{ $chapter->chapter }}</h5>
                @endforeach
            @endif
        </div>
    </div>
</div>

<div class="col-lg-9 col-sm-12 wow fadeInUp" data-wow-delay="0.7s" style="word-break: break-all;">
    @if ($firstChapter)
        <div class="service-item text-center pt-3">
            <div class="p-4" style="text-align: left;">
                <h3>Chapter: {{ $firstChapter->title }}</h3>
                @if ($notes->isEmpty())
                    <p>No notes in this chapter.</p>
                @else
                    <ul>
                        @foreach ($notes as $note)
                            <a class="boh" href="{{ route('login') }}" style="padding: 4vh;">
                                <li>{{ $note->note }}</li>
                            </a>
                        @endforeach
                    </ul>
                @endif
            </div>
        </div>
    @else
        <p>No chapters available for this book.</p>
    @endif
</div>

    </div>
</div>
</div>
@endsection