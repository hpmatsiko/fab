@extends('layouts.common')
@section('title','Home Page')
@section('content')

<div class="container-xxl py-5">
    <div class="container">
        <div style="display: flex;justify-content: space-around;" class="row g-4">
<h1>{{ $category->book_category }}</h1>

@if ($subcategories->isEmpty())
    <p>No subcategories found in this category.</p>
@else
    @foreach ($subcategories as $subcategory)
     <div class="col-lg-4 col-sm-12 wow fadeInUp" data-wow-delay="0.7s" style="word-break: break-all;">
             <div class="service-item text-center pt-3" >
                <div class="p-4" style="text-align: left;">
        <h2>{{ $subcategory->sub_category }}</h2>
        @php
            $subcategoryBooks = $books->where('sub_category_id', $subcategory->id);
        @endphp
        @if ($subcategoryBooks->isEmpty())
            <p>No books found in this subcategory.</p>
        @else
            <ul>
                @foreach ($subcategoryBooks as $book)
                    <a class="boh" href="{{ route("login") }}" style="padding: 4vh;"><li>
                        {{ $book->bname }}
                       
                        @if ($book->image)
                            <img src="{{ asset('bookImages/' . $book->image) }}" alt="Book Image" width="100">
                        @endif
                    </li></a>
                @endforeach
            </ul>
        @endif
                   </div>
            </div>
        </div>
    @endforeach
@endif
    </div>
</div>
</div>
@endsection